## 1.Architecture design
```mermaid
graph TD
  A["用户浏览器"] --> B["React 前端（Vite）"]
  B --> C["API Client（axios/fetch）"]
  C --> D["Node.js/Express 后端（可选启动）"]
  D --> E["MongoDB"]

  subgraph "Frontend Layer"
    B
    C
  end

  subgraph "Backend Layer"
    D
  end

  subgraph "Data Layer"
    E
  end
```

架构取舍（面向重构目标）：
- 前端优先：保证 `frontend` 可独立 `npm run dev` 预览并对齐原型；当后端未启动时，允许切换到 mock 数据以完成 UI 对齐。
- 后端收敛：仅保留支撑前端的最小 REST API 路径（统一前缀 `/api`），避免为“原型对齐”引入过多业务复杂度。

## 2.Technology Description
- Frontend: React + vite（现有工程）
- Backend: Node.js + Express（现有工程）
- Database: MongoDB（docker-compose / 本地服务）

## 3.Route definitions
| Route | Purpose |
|-------|---------|
| /auth | 登录与注册入口（单页内切换登录/注册模式） |
| / | 首页（Welcome），展示导航与入口 |
| /dashboard | 看板（To Do / In Progress / Review / Done） |
| /tasks | 任务表格页（CRUD/状态变更/优先级展示） |
| /focus | 专注计时页（番茄钟 + 任务绑定） |
| /settings | 设置页（按原型分区按钮，占位或逐步实现） |

## 4.API definitions (If it includes backend services)
### 4.1 Core API
健康检查
- `GET /api/health`

认证
- `POST /api/auth/register`
- `POST /api/auth/login`

任务
- `GET /api/tasks`
- `POST /api/tasks`
- `GET /api/tasks/:id`
- `PUT /api/tasks/:id`
- `DELETE /api/tasks/:id`
- `PATCH /api/tasks/:id/status`
- `POST /api/tasks/:id/subtask`

模块
- `GET /api/modules`
- `POST /api/modules`
- `PUT /api/modules/:id`
- `DELETE /api/modules/:id`

计时/统计
- `POST /api/timer/start`
- `POST /api/timer/stop`
- `GET /api/timer/logs/:taskId`
- `GET /api/timer/weekly-stats/:userId`

### 4.2 Shared TypeScript types（用于前后端契约，哪怕实现仍是 JS）
```ts
export type TaskStatus = 'todo' | 'in_progress' | 'review' | 'done'
export type TaskPriority = 'H' | 'M' | 'L'

export interface User {
  id: string
  username: string
  email: string
  createdAt: string
}

export interface Module {
  id: string
  userId: string
  name: string
  color?: string
  createdAt: string
}

export interface Subtask {
  id: string
  title: string
  done: boolean
}

export interface Task {
  id: string
  userId: string
  name: string
  deadline?: string
  moduleId?: string
  priority: TaskPriority
  status: TaskStatus
  createdAt: string
  timeSpentSec: number
  subtasks?: Subtask[]
}

export interface TimerLog {
  id: string
  userId: string
  taskId: string
  startTime: string
  endTime: string
  durationSec: number
}
```

## 5.Server architecture diagram (If it includes backend services)
```mermaid
graph TD
  A["HTTP 请求（/api/*）"] --> B["Express Router"]
  B --> C["Controller"]
  C --> D["Service（可选）"]
  D --> E["Model/Repository（Mongoose）"]
  E --> F["MongoDB"]

  subgraph "Server"
    B
    C
    D
    E
  end
```

## 6.Data model(if applicable)
### 6.1 Data model definition
```mermaid
erDiagram
  USER ||--o{ TASK : owns
  USER ||--o{ MODULE : owns
  TASK ||--o{ TIMER_LOG : records

  USER {
    string id
    string username
    string email
    string passwordHash
    string createdAt
  }

  MODULE {
    string id
    string userId
    string name
    string color
    string createdAt
  }

  TASK {
    string id
    string userId
    string moduleId
    string name
    string deadline
    string priority
    string status
    int timeSpentSec
    string createdAt
  }

  TIMER_LOG {
    string id
    string userId
    string taskId
    string startTime
    string endTime
    int durationSec
  }
```

### 6.2 Data Definition Language
MongoDB 场景不使用 DDL；建议以集合维度建立索引（示例）：
- tasks: `userId + status` 复合索引（看板查询），`userId + deadline`（任务截止排序）
- modules: `userId + name` 唯一或普通索引（按用户维度）
- timer_logs: `userId + startTime`（周统计聚合）

