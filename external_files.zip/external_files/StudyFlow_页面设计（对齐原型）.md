# 全局设计规范（桌面优先）

## Global Styles
- 视觉语言：手绘/涂鸦感（粗黑描边 + 大圆角 + 轻微阴影偏移），导航激活态使用斜纹填充。
- 字体：`"Comic Sans MS", "Chalkboard SE", "Marker Felt", "Microsoft YaHei", sans-serif`（与原型一致）。
- 颜色（取自原型 CSS 变量）：
  - Ink（描边/主文字）：`#1a1a1a`
  - Background：`#ffffff`
  - 页面背景：浅灰（如 `#f0f0f0/#f7f7f7/#f5f5f5`）
  - Home 主色（苹果绿）：`#b5d146`
  - Dashboard 面板：todo `#fbc4c4` / progress `#fdf2b1` / review `#b1d7fd` / done `#b1fdbd`
- 通用组件状态：
  - Hover：轻微上移（`translateY(-2px)`）或阴影增强
  - Active/Pressed：阴影缩短 + 位移（模拟“按下”）
- 响应式：桌面为主（内容最大宽 1000~1100px）；小屏（<=768/900）降级为单列布局。

---

# 页面设计说明

## 1) 登录/注册页（/auth）
### Layout
- 单栏居中卡片（Flex 居中）；卡片外有“主容器手绘边框”。

### Meta Information
- Title: `StudyFlow - Auth`
- Description: `登录或注册以开始使用 StudyFlow`

### Page Structure
- 顶部：StudyFlow 标识（可复用 Home 的苹果图形或简化文字）。
- 中部：Tab（Login/Register）+ 表单。
- 底部：错误提示区 + 提交按钮。

### Sections & Components
- AuthTabs：切换登录/注册（不改变路由）。
- AuthForm：字段（email/username/password 取后端约定）；提交时展示 loading。
- AuthErrorBanner：展示后端错误或校验错误。

---

## 2) 首页 Welcome（/）
### Layout
- 主容器 `.main-frame`：固定最大宽 + 居中；内部纵向 Flex。

### Meta Information
- Title: `StudyFlow - Welcome`
- Description: `Welcome to StudyFlow`
- OG: 标题与描述同上。

### Page Structure
- 顶部：导航条（居中，pill 按钮）。
- 中部：欢迎标题 + 苹果图形。

### Sections & Components
- TopNav：Home/Dashboard/Tasks/Focus/Settings；hover 上移；当前页可不高亮或保持默认。
- Hero：大标题（48px）+ SVG 图标（hover wobble 动画可选）。

---

## 3) Dashboard 看板（/dashboard）
### Layout
- 主容器内：CSS Grid（2x2），间距 30px；小屏改为单列。

### Meta Information
- Title: `StudyFlow - Dashboard`
- Description: `在看板中管理任务流转`

### Page Structure
- 顶部：导航条（Dashboard 高亮为斜纹背景）。
- 主体：四象限面板（To Do / In Progress / Review / Done）。

### Sections & Components
- KanbanGrid：四个 Panel。
- Panel：标题居中；内部 `chip-container` 自动换行。
- TaskChip：椭圆 pill；支持拖拽（实现时可用 dnd-kit/react-beautiful-dnd 之一）。
- 状态颜色：严格对齐原型变量。

---

## 4) Tasks 任务页（/tasks）
### Layout
- 顶部导航 + 工具栏 + 表格区（表格外包一层圆角边框容器）。

### Meta Information
- Title: `StudyFlow - Tasks`
- Description: `以表格方式管理你的学习任务`

### Page Structure
- 顶部：导航条（Tasks 斜纹高亮）。
- 工具栏：左侧 Add New Task，右侧 Priority legend。
- 表格：居中对齐，列结构与原型一致。

### Sections & Components
- Toolbar：Add 按钮使用“按下”交互（阴影位移）。
- TaskTable：
  - 列：Name / Deadline / Module / Priority / Create Time / Status / Operation
  - Priority：H/M/L 彩色字
  - Status：To Do 红、Done 绿（可扩展更多状态映射）
- RowActions：Edit/Delete pill 按钮。
- TaskModal（建议）：新增/编辑弹窗，避免新增页面破坏原型信息结构。

---

## 5) Focus 专注页（/focus）
### Layout
- 两列网格（`1.2fr 1fr`）；小屏单列。

### Meta Information
- Title: `StudyFlow - Focus`
- Description: `使用番茄钟提升专注`

### Page Structure
- 顶部：导航条（Focus 斜纹高亮）。
- 左侧：大圆环计时器 + Cancel/Pause 按钮。
- 右侧：Current Task / Next Task 两张卡。

### Sections & Components
- TimerRing：固定尺寸（桌面 420，移动端 320）；中间大号时间。
- TimerControls：Cancel（灰）、Pause/Resume（橙）。
- TaskCards：黄色（current）、紫色（next），文字居中。

---

## 6) Settings 设置页（/settings）
### Layout
- 顶部导航 + 单列设置面板；面板内按 section 垂直堆叠。

### Meta Information
- Title: `StudyFlow - Settings`
- Description: `管理账号与偏好设置`

### Page Structure
- 顶部：导航条（Settings 斜纹高亮）。
- 主体：Account/Security/Privacy/Preferences 四区块；每区块两颗 pill 按钮。

### Sections & Components
- SettingsPanel：粗边框 + 大圆角。
- Section：标题 + divider + ButtonRow。
- PillButton：按区块使用蓝/黄/绿/红色背景与对应斜纹。
- 占位交互：未实现的按钮点击后提示“Coming soon”。

> 原型 HTML（本仓库内）用于逐像素对齐参考：
> - `docs/design/prototypes/home_page.html`
> - `docs/design/prototypes/dash_board.html`
> - `docs/design/prototypes/tasks_mainPage.html`
> - `docs/design/prototypes/focus_mainPage.html`
> - `docs/design/prototypes/settings_mainPage.html`
