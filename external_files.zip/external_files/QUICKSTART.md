# 🚀 Quick Start Guide - StudyFlow

## Prerequisites
- Docker & Docker Compose installed
- Node.js 18+ (for local development)
- MongoDB (automatically provided in Docker)

## Option 1: Run with Docker (Recommended)

### One Command Startup
```bash
cd /Users/henrysang/Documents/IT5007/StudyFlow
docker-compose up --build
```

**Services will start automatically:**
- ✅ MongoDB: `mongodb://localhost:27017`
- ✅ Backend API: `http://localhost:5000`
- ✅ Frontend: `http://localhost:5173`

### Check if Running
```bash
# Verify backend health
curl http://localhost:5000/api/health

# View logs
docker-compose logs -f backend
docker-compose logs -f frontend
```

### Cleanup
```bash
docker-compose down
docker-compose down -v  # Also remove volumes
```

---

## Option 2: Local Development Setup

### Backend Setup
```bash
cd backend

# Install dependencies
npm install

# Create .env file
cp .env.example .env

# Start backend
npm start
# Server runs on http://localhost:5000
```

### Frontend Setup (in new terminal)
```bash
cd frontend

# Install dependencies
npm install

# Create .env file
cp .env.example .env

# Start development server
npm run dev
# Browser opens to http://localhost:5173
```

### Database Connection
Make sure MongoDB is running locally:
```bash
# If using Docker MongoDB only
docker run -d -p 27017:27017 --name mongo mongo:latest
```

---

## 🔑 Demo Credentials

After login, use any credentials (mock auth):
```
Email: test@studyflow.com
Password: password123
```

---

## 📋 Features to Try

### 1. **Dashboard**
- View kanban board with 4 columns
- See sample tasks with different priorities
- Observe color-coded status badges

### 2. **Create New Task**
- Click "Add New Task" button
- Fill in title, description, priority, deadline
- Task appears in "To Do" column

### 3. **Manage Tasks**
- Click task to view details
- Edit or delete from menu
- Add subtasks with checklist

### 4. **Pomodoro Timer**
- Click "Focus" button on any task
- 25-minute timer countdown
- Auto-save focus time

### 5. **Module Settings**
- Go to Settings page
- Create course modules (e.g., IT5007, CS5242)
- Assign custom colors to each module

### 6. **Weekly Statistics**
- View bar chart on dashboard
- See tasks completed per day
- Track total focus hours

---

## ⚙️ Project Structure

```
StudyFlow/
├── backend/                    # Node.js/Express API
│   ├── server.js              # Main server file
│   ├── models/                # MongoDB schemas
│   ├── routes/                # API endpoints
│   ├── controllers/           # Business logic
│   ├── Dockerfile
│   └── package.json
│
├── frontend/                   # React + Vite app
│   ├── src/
│   │   ├── pages/             # HomePage, Dashboard, etc.
│   │   ├── components/        # KanbanBoard, TaskForm, etc.
│   │   ├── services/          # API client
│   │   ├── hooks/             # Custom React hooks
│   │   ├── App.jsx            # Main component
│   │   └── main.jsx           # Entry point
│   ├── Dockerfile
│   ├── nginx.conf
│   └── package.json
│
├── docker-compose.yml         # Multi-container setup
├── PROJECT_STRUCTURE.md       # Detailed documentation
└── QUICKSTART.md              # This file
```

---

## 🔧 Available Scripts

### Backend
```bash
npm start      # Start production server
npm run dev    # Start with nodemon (auto-reload)
npm test       # Run tests
```

### Frontend
```bash
npm run dev    # Start dev server with HMR
npm run build  # Production build
npm run lint   # ESLint code quality
npm run preview # Preview production build
```

---

## 🐛 Troubleshooting

### Port Already in Use
```bash
# Find process using port 5000
lsof -i :5000
# Kill it
kill -9 <PID>

# Or change in docker-compose.yml
# Change "5000:5000" to "5001:5000"
```

### MongoDB Connection Failed
```bash
# Check MongoDB is running
docker ps | grep mongo

# Restart MongoDB container
docker-compose up mongo -d
```

### Frontend Can't Reach Backend
```bash
# Check backend URL in frontend/.env
# Should be: VITE_API_URL=http://localhost:5000/api

# Verify backend is running
curl http://localhost:5000/api/health
```

### Clear Docker Cache
```bash
docker-compose down -v
rm -rf node_modules package-lock.json
docker-compose up --build --no-cache
```

---

## 📚 API Documentation

### Authentication
```
POST /api/auth/register
  Body: { username, email, password }

POST /api/auth/login
  Body: { email, password }
  Response: { token, userId, username }
```

### Tasks
```
GET    /api/tasks?userId=xxx
POST   /api/tasks
PUT    /api/tasks/:id
DELETE /api/tasks/:id
PATCH  /api/tasks/:id/status
POST   /api/tasks/:id/subtask
```

### Modules
```
GET  /api/modules?userId=xxx
POST /api/modules
PUT  /api/modules/:id
DELETE /api/modules/:id
```

### Timer
```
POST /api/timer/start
POST /api/timer/stop
GET  /api/timer/logs/:taskId
GET  /api/timer/weekly-stats/:userId
```

---

## 🎯 Next Steps

1. **Customize**: Edit pages, colors, and layouts in `/frontend/src`
2. **Extend API**: Add more routes in `/backend/routes` and controllers
3. **Add Features**: Implement drag-and-drop with `react-beautiful-dnd`
4. **Deploy**: Push to Docker Hub or cloud platform

---

## 📖 More Documentation

- **PROJECT_STRUCTURE.md** - Detailed architecture and file organization
- **README.md** - Original project proposal and requirements
- **Backend routes** - See `/backend/routes/*`
- **Frontend components** - See `/frontend/src/components/*`

---

**Last Updated**: 2026-03-31  
**Version**: 1.0.0
