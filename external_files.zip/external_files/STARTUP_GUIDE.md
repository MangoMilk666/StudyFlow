# 📘 StudyFlow 启动与调试指南

## 1️⃣ Docker 启动（推荐）

### 快速启动

```bash
cd /path/to/StudyFlow

# 启动所有服务（后台）
docker-compose up -d

# 查看容器状态
docker ps
```

### 访问应用

- **前端**：http://localhost:5173
- **后端 API**：http://localhost:8000/api
- **API 健康检查**：http://localhost:8000/api/health

### 停止应用

```bash
# 停止所有服务并保留数据
docker-compose down

# 停止并删除所有数据
docker-compose down -v
```

### 查看日志

```bash
# 查看所有容器日志
docker-compose logs -f

# 仅查看前端日志
docker-compose logs -f studyflow-frontend

# 仅查看后端日志
docker-compose logs -f studyflow-backend

# 仅查看数据库日志
docker-compose logs -f studyflow-db
```

---

## 2️⃣ 本地开发启动（无 Docker）

### 前置条件

- Node.js 18+ 或 20+
- npm 或 yarn
- MongoDB（本地或远程）

### 后端启动

```bash
cd backend

# 安装依赖
npm install

# 启动服务
npm start
# 运行在 http://localhost:8000
```

**环境变量** (`.env`)：
```
MONGO_URI=mongodb://localhost:27017/studyflow
JWT_SECRET=your_secret_key
NODE_ENV=development
PORT=8000
```

### 前端启动（新终端）

```bash
cd frontend

# 安装依赖
npm install

# 开发模式启动
npm run dev
# 运行在 http://localhost:5173
```

**环境变量** (`.env`）：
```
VITE_API_URL=http://localhost:8000/api
```

---

## 3️⃣ 故障排除

### 前端显示空白或错误

**错误信息**：`Uncaught Error: Minified React error #130`

**原因**：某个 React 组件导入错误（例如导入了非组件的对象）

**解决方案**：
```bash
# 1. 检查浏览器控制台错误
# 2. 清空浏览器缓存
# 3. 重新启动前端容器
docker-compose restart studyflow-frontend

# 4. 重新构建前端镜像
docker-compose build --no-cache studyflow-frontend
docker-compose up
```

### 后端 API 无响应

```bash
# 1. 检查后端容器的日志
docker logs studyflow-backend

# 2. 检查后端是否可达
curl -v http://localhost:8000/api/health

# 3. 重启后端服务
docker-compose restart studyflow-backend
```

### MongoDB 连接失败

```bash
# 1. 检查数据库容器状态
docker ps | grep studyflow-db

# 2. 检查数据库日志
docker logs studyflow-db

# 3. 重启数据库容器
docker-compose restart studyflow-db

# 4. 清空数据并重启
docker-compose down -v
docker-compose up -d
```

### 端口被占用

```bash
# 查找占用指定端口的进程
lsof -i :5173   # 前端
lsof -i :8000   # 后端
lsof -i :27017  # 数据库

# 杀死占用端口的进程（macOS/Linux）
kill -9 <PID>

# 更改 docker-compose.yml 中的端口配置
# 例如将 5173 改为 5174，8000 改为 8001，等等
```

---

## 4️⃣ 常见操作命令

### 查看容器统计信息

```bash
docker-compose stats
```

### 进入容器 Shell

```bash
# 进入前端容器
docker exec -it studyflow-frontend sh

# 进入后端容器
docker exec -it studyflow-backend sh

# 进入数据库容器
docker exec -it studyflow-db sh
```

### 查看容器内的文件系统

```bash
# 前端应用目录
docker exec studyflow-frontend ls -la /app

# 后端应用目录
docker exec studyflow-backend ls -la /app
```

### 强制重新构建镜像

```bash
# 不使用缓存重新构建所有镜像
docker-compose build --no-cache

# 重新启动
docker-compose up -d
```

---

## 5️⃣ 访问应用数据

### 通过 MongoDB 客户端（本地）

```bash
# 连接到数据库
mongosh mongodb://localhost:27017/studyflow

# 查看所有集合
show collections

# 查看用户数据
db.users.find()

# 查看任务数据
db.tasks.find()

# 查看模块数据
db.modules.find()

# 查看计时器日志
db.timerlogs.find()
```

### 通过 API（推荐）

```bash
# 获取所有任务
curl http://localhost:8000/api/tasks

# 获取所有模块
curl http://localhost:8000/api/modules

# 获取计时器日志
curl http://localhost:8000/api/timer/logs
```

---

## 6️⃣ 性能监控

### 查看容器资源使用情况

```bash
# 实时监控所有容器
docker-compose stats --no-stream

# 查看特定容器的详细信息
docker inspect studyflow-frontend | grep -A 5 "Memory"
```

### 检查前端性能

在浏览器开发者工具中：
1. **Performance 标签**：录制页面加载
2. **Network 标签**：检查 API 请求速度
3. **Console 标签**：查看任何错误消息

---

## 7️⃣ 更新和维护

### 更新依赖

```bash
# 后端
cd backend
npm update
npm audit fix

# 前端
cd frontend
npm update
npm audit fix
```

### 清理 Docker 资源

```bash
# 删除未使用的镜像
docker image prune

# 删除未使用的卷
docker volume prune

# 完全清理（谨慎！）
docker system prune -a --volumes
```

---

## 📝 常见问题 (FAQ)

**Q: 如何修改前端端口？**
A: 在 `docker-compose.yml` 中修改 `ports: ["5174:5173"]`

**Q: 如何修改后端端口？**
A: 在 `docker-compose.yml` 中修改 `ports: ["8001:8000"]`，并更新 `MONGO_URI`

**Q: 前端无法连接到后端？**
A: 检查 `frontend/src/services/api.js` 中的 `API_BASE_URL` 是否正确

**Q: 数据没有持久化？**
A: 确保在 `docker-compose.yml` 中配置了卷（volume）

**Q: 如何备份数据库？**
A: 
```bash
docker exec studyflow-db mongodump --out /backup
docker cp studyflow-db:/backup ./backup
```

---

祝您使用愉快！🎉 如有问题，请查看日志或联系开发团队。
