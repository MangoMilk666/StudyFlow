## 1. Product Overview
StudyFlow 是面向学生的学习任务管理 Web 应用，包含看板任务流与番茄钟专注。
本次重构目标：本地可运行预览、前端视觉/布局对齐 docs 高保真原型、后端仅保留/收敛为简单 API 路径以支撑前端联调。

## 2. Core Features

### 2.1 User Roles
| 角色 | 注册方式 | 核心权限 |
|------|----------|----------|
| 普通用户 | 邮箱/用户名注册 | 登录后可管理任务/模块、使用看板、专注计时、查看基础统计、修改基础设置 |

### 2.2 Feature Module
本应用（重构版）由以下核心页面构成：
1. **登录/注册页**：登录、注册、错误提示。
2. **首页（Welcome）**：主导航、产品入口（跳转到 Dashboard/Tasks/Focus/Settings）。
3. **Dashboard 看板页**：四列/四象限任务状态展示、拖拽或快捷变更状态。
4. **Tasks 任务页**：任务列表表格、新增/编辑/删除、设置优先级/截止日期/所属模块、变更状态。
5. **Focus 专注页**：番茄钟计时、选择当前任务/下一任务、暂停/继续/取消、结束后写入专注记录。
6. **Settings 设置页**：账号/安全/隐私/偏好等设置入口（按原型保留按钮位）。

### 2.3 Page Details
| Page Name | Module Name | Feature description |
|-----------|-------------|---------------------|
| 登录/注册页 | 表单 | 提交登录/注册信息；展示表单校验与后端错误信息；成功后跳转首页/看板 |
| 登录/注册页 | 会话管理 | 保存登录态（token 或 cookie）；提供退出登录入口（可放在 Settings） |
| 首页（Welcome） | 顶部导航 | 展示 Home/Dashboard/Tasks/Focus/Settings；高亮当前页；支持跳转 |
| 首页（Welcome） | 欢迎区 | 展示标题与品牌图形（苹果）；作为“进入应用”的轻量落地页 |
| Dashboard 看板页 | 状态面板 | 展示 To Do / In Progress / Review / Done 四面板；面板内展示任务 chip |
| Dashboard 看板页 | 状态变更 | 通过拖拽或面板内操作变更任务状态；变更后持久化（调用 tasks status API） |
| Tasks 任务页 | 列表表格 | 分列展示 Name/Deadline/Module/Priority/Create Time/Status；支持分页或滚动（实现其一即可） |
| Tasks 任务页 | 任务 CRUD | 新增任务；编辑任务字段；删除任务；操作后刷新列表 |
| Tasks 任务页 | 状态/优先级呈现 | 使用 H/M/L 与颜色标识优先级；To Do/Done 等状态颜色与原型一致 |
| Focus 专注页 | 计时器 | 默认 25:00（可配置）；支持开始/暂停/继续/取消；到时提示 |
| Focus 专注页 | 任务绑定 | 选择当前任务与下一任务（从任务列表中选择）；展示任务名 |
| Focus 专注页 | 专注记录 | 结束时写入 TimerLog；累计到任务 time_spent；可为周统计提供数据 |
| Settings 设置页 | 分区按钮 | 按原型展示 Account/Security/Privacy/Preferences 分区与按钮；按钮可先为占位（后续逐步实现） |
| 全局 | 本地可运行预览 | 提供无 Docker 与 Docker 两种启动方式；前端 `npm run dev` 可预览完整 UI；后端可选启动用于联调 |
| 全局 | 原型对齐规范 | 保持“手绘边框+圆角+斜纹激活态+手写字体”的视觉语言；页面信息结构与原型一致 |
| 全局 | 后端 API 预留 | 前端统一走 `/api/**`；当后端不可用时允许前端使用 mock 数据（用于 UI 对齐与演示） |

## 3. Core Process
- 用户登录/注册：在登录/注册页输入信息 → 调用 `/api/auth/*` → 成功后进入首页。
- 用户任务管理：进入 Tasks → 新增/编辑/删除任务 → 调用 `/api/tasks` → 列表刷新；必要时调用 `/api/modules` 获取模块选项。
- 用户看板流转：进入 Dashboard → 拖拽/快捷操作变更状态 → 调用 `/api/tasks/:id/status` → 看板实时更新。
- 用户专注计时：进入 Focus → 选择当前任务 → 开始计时 → 暂停/继续/取消 → 结束后调用 `/api/timer/stop` 写入日志，并更新任务累计时间。
- 用户设置：进入 Settings → 点击各分区按钮（可先占位提示“待实现”）。

```mermaid
graph TD
  A["登录/注册页"] --> B["首页（Welcome）"]
  B --> C["Dashboard 看板页"]
  B --> D["Tasks 任务页"]
  B --> E["Focus 专注页"]
  B --> F["Settings 设置页"]
  C --> D
  D --> E
  E --> D
  F --> A
```

> 原型参考（本仓库内）：
> - Home：<img src="../../docs/design/wireframes/home_page1.excalidraw.png" width="720" />
> - Dashboard：<img src="../../docs/design/wireframes/dash_board.excalidraw.png" width="720" />
> - Tasks：<img src="../../docs/design/wireframes/tasks_mainPage.excalidraw.png" width="720" />
> - Focus：<img src="../../docs/design/wireframes/focus_mainPage.excalidraw.png" width="720" />
> - Settings：<img src="../../docs/design/wireframes/settings_mainPage.excalidraw.png" width="720" />
